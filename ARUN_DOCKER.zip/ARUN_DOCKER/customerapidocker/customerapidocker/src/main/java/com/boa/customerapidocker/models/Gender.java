package com.boa.customerapidocker.models;

public enum Gender {
MALE,FEMALE,TRANSGENDER
}
