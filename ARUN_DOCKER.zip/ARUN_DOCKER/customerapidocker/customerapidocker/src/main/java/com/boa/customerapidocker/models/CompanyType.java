package com.boa.customerapidocker.models;

public enum CompanyType {
GOVT,NGO,PUBLIC,PRIVATE
}
