#!/bin/bash

echo "Creaing 'web-app'"
kubectl create deployment web-app --image=nginx
sleep 10
echo "Deleting 'web-app'"
kubectl delete deployment web-app
